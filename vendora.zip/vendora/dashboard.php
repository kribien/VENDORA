<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body class="flex h-screen"> <!-- Sidebar -->
    <div class="bg-blue-900 text-white w-1/4 p-4 flex flex-col">
        <div class="text-lg font-bold mb-4">Nom Commerçant</div> <button
            class="bg-blue-500 text-white py-2 px-4 rounded mb-2">Costumers</button> <button
            class="bg-blue-500 text-white py-2 px-4 rounded mb-2">History</button> <button
            class="bg-blue-500 text-white py-2 px-4 rounded mb-2">Add a product</button> <button
            class="bg-blue-500 text-white py-2 px-4 rounded mb-2">Earnings</button> <button
            class="bg-blue-500 text-white py-2 px-4 rounded mb-2">My products</button> <button
            class="bg-blue-500 text-white py-2 px-4 rounded mt-auto">Profile</button>
    </div> <!-- Main Content -->
    <div class="flex-1 flex flex-col"> <!-- Header -->
        <div class="bg-yellow-500 text-center py-2 text-sm font-semibold"> Authentic • Sustainable • Proudly Cameroonian
        </div> <!-- Search and Icons -->
        <div class="flex items-center justify-between p-4">
            <div class="flex items-center"> <i class="fas fa-bars text-2xl mr-4"></i>
                <div class="relative"> <input type="text" class="bg-gray-100 rounded-full pl-10 pr-4 py-2 w-64"
                        placeholder="Search"> <i class="fas fa-search absolute left-3 top-2 text-gray-500"></i> </div>
            </div>
        </div>
    </div>
</body>

</html>